#ifndef MKDIRP_H
#define MKDIRP_H

#include <stdbool.h>

bool mkdirp(const char *path);

#endif /* MKDIRP_H */
