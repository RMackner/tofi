#ifndef SHM_H
#define SHM_H

#include <stddef.h>

int shm_allocate_file(size_t size);

#endif /* SHM_H */
